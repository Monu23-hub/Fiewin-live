ImageView logoImage = findViewById(R.id.appLogo);
logoImage.setImageResource(R.drawable.logo);