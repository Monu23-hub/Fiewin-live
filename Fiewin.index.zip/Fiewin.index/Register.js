document.getElementById("registerForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const password = document.getElementById("regPassword").value.trim();

  if (name === "" || phone === "" || password === "") {
    alert("Please fill all fields!");
    return;
  }

  alert("Registration Successful!");
  window.location.href = "index.html";
});