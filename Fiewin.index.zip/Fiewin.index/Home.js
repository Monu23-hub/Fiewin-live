let walletBalance = 0;

if (localStorage.getItem('walletBalance')) {
  walletBalance = parseFloat(localStorage.getItem('walletBalance'));
  document.getElementById("walletBalance").innerText = walletBalance;
}

function startGame() {
  window.location.href = "game.html";
}

function depositMoney() {
  let amount = prompt("Enter amount to add:");
  if (amount && !isNaN(amount)) {
    walletBalance += parseFloat(amount);
    localStorage.setItem('walletBalance', walletBalance);
    document.getElementById("walletBalance").innerText = walletBalance;
    alert("₹" + amount + " added successfully!");
  } else {
    alert("Invalid Amount!");
  }
}