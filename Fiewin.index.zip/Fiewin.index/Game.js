let walletBalance = 0;

if (localStorage.getItem('walletBalance')) {
  walletBalance = parseFloat(localStorage.getItem('walletBalance'));
}

function placeBet() {
  let bet = parseFloat(document.getElementById('betAmount').value);

  if (isNaN(bet) || bet <= 0) {
    alert("Enter a valid bet amount!");
    return;
  }

  if (bet > walletBalance) {
    alert("Not enough balance!");
    return;
  }

  let random = Math.random();
  if (random < 0.5) {
    walletBalance += bet;
    document.getElementById('gameResult').innerHTML = `<h2 style="color: #00ff00;">You Won! New Balance: ₹${walletBalance}</h2>`;
  } else {
    walletBalance -= bet;
    document.getElementById('gameResult').innerHTML = `<h2 style="color: #ff0000;">You Lost! New Balance: ₹${walletBalance}</h2>`;
  }

  localStorage.setItem('walletBalance', walletBalance);
}

function goHome() {
  window.location.href = "home.html";
}